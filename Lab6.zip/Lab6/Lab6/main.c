/*
 * Lab6.c
 *
 * Created: 24/04/2024 11:28:23
 * Author : Ovall
 */ 
// Definici�n de la frecuencia del procesador en Hz
#define F_CPU 16000000UL

#include <avr/io.h>
#include <avr/interrupt.h>
#include <util/delay.h>
#include <stdio.h>
#include <stdlib.h>
#include "ADC/ADC.h" // Se incluye el header para el manejo del ADC

void initUART9600(void); // Prototipo de la funci�n de inicializaci�n UART
void writeUART(char caracter); // Prototipo de la funci�n para escribir un car�cter por UART
void writeTextUART(char* texto); // Prototipo de la funci�n para escribir un texto por UART

volatile char leds; // Variable para almacenar el estado de los LEDs
volatile char opcion; // Variable para almacenar la opci�n seleccionada
volatile uint8_t menu = 0; // Variable para controlar el men�

int main(void)
{
	DDRD |= 0xFF; // Se configuran los pines del puerto D como salidas
	DDRB |= 0x3F; // Se configuran los pines del puerto B como salidas
	initUART9600(); // Se inicializa la comunicaci�n UART a 9600 baudios
	init_ADC(0, 0, 128); // Se inicializa el ADC en el canal 0 con un prescaler de 128
	sei(); // Se habilitan las interrupciones globales
	
	// Se env�a un saludo inicial por UART
	writeUART('H');
	writeUART('o');
	writeUART('l');
	writeUART('a');
	writeUART(' ');
	writeUART('m');
	writeUART('u');
	writeUART('n');
	writeUART('d');
	writeUART('o');
	writeUART('\n');
	writeUART('\n');
	
	// Se env�an instrucciones para el men� por UART
	writeTextUART("1 para recibir valor\n");
	writeTextUART("2 para enviar valor\n");
	
	while (1)
	{
		// Se verifica si se seleccion� una opci�n del men�
		if (menu == 1){
			// Si la opci�n es 1, se lee un valor del ADC y se env�a por UART
			uint8_t valor = readADC(4);
			writeTextUART("Valor recibido: ");
			char str[4];
			sprintf(str, "%d", valor);
			writeTextUART(str);
			writeUART('\n');
			writeTextUART("1 para recibir valor\n");
			writeTextUART("2 para enviar valor\n");
			menu = 0;
		}
	}
}

// Funci�n de inicializaci�n UART a 9600 baudios
void initUART9600(void){
	DDRD &= ~(1 << DDD0); // Se configura el pin RX como entrada
	DDRD |= (1 << DDD1); // Se configura el pin TX como salida
	
	UCSR0A = 0; // Se limpian los bits de UCSR0A
	UCSR0A |= (1 << U2X0); // Se activa la doble velocidad de transmisi�n
	
	UCSR0B = 0; // Se limpian los bits de UCSR0B
	UCSR0B |= (1 << RXCIE0) | (1 << RXEN0) | (1 << TXEN0); // Se habilita la recepci�n y transmisi�n UART
	
	UCSR0C = 0; // Se limpian los bits de UCSR0C
	UCSR0C |= (1 << UCSZ01) | (1 << UCSZ00); // Se configura el tama�o del marco de datos a 8 bits
	
	UBRR0 = 207; // Se configura el registro de baudios para 9600 baudios
}

// Funci�n para escribir un car�cter por UART
void writeUART(char caracter){
	while (!(UCSR0A & (1<<UDRE0))); // Se espera a que el buffer de transmisi�n est� vac�o
	UDR0 = caracter; // Se env�a el car�cter
}

// Funci�n para escribir un texto por UART
void writeTextUART(char* texto){
	uint8_t i;
	for(i = 0; texto[i] != '\0'; i++){
		while (!(UCSR0A & (1<<UDRE0))); // Se espera a que el buffer de transmisi�n est� vac�o
		UDR0 = texto[i]; // Se env�a el car�cter del texto
	}
}

// Rutina de servicio de interrupci�n para la recepci�n UART
ISR(USART_RX_vect){
	opcion = UDR0; // Se lee la opci�n recibida por UART
	writeTextUART("--------------\n");
	while (!(UCSR0A & (1<<UDRE0))); // Se espera a que el buffer de transmisi�n est� vac�o
	UDR0 = opcion; // Se env�a la opci�n recibida por UART
	writeTextUART("\n--------------\n");
	if (menu == 0){
		// Si no se est� en el men�, se verifica la opci�n recibida
		if (opcion == '1'){
			menu = 1;
			writeTextUART("Opci�n 1\n");
			} else if (opcion == '2') {
			menu = 2;
			writeTextUART("Opci�n 2\n");
			writeTextUART("Envie el valor que quiere mostrar en las leds\n");
		}
		} else {
		// Si se est� en el men�, se maneja la opci�n seleccionada
		if (menu == 2){
			// Si la opci�n es 2, se espera un valor para controlar los LEDs
			writeTextUART("Valor: ");
			leds = opcion;
			while (!(UCSR0A & (1<<UDRE0))); // Se espera a que el buffer de transmisi�n est� vac�o
			PORTD = 0; // Se limpian los bits del puerto D
			PORTB = 0; // Se limpian los bits del puerto B
			PORTD |= (leds << 5) & 0xFF; // Se establecen los bits de los LEDs en el puerto D
			PORTB |= (leds >> 3) & 0x3F; // Se establecen los bits de los LEDs en el puerto B
			UDR0 = leds; // Se env�a el valor de los LEDs
			writeUART('\n');
			writeTextUART("1 para recibir valor\n");
			writeTextUART("2 para enviar valor\n");
			menu = 0;
			} else {
			// Si se selecciona una opci�n no v�lida
			writeTextUART("Opci�n no v�lida\n");
			writeTextUART("1 para recibir valor\n");
			writeTextUART("2 para enviar valor\n");
		}
	}
}